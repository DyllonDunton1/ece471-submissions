#!/bin/sh

#print 1-wire is cool!
echo "1-wire is cool!"
