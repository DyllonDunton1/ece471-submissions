#define SENSOR_NAME "/sys/bus/w1/devices/28-000005aaf7ed/w1_slave"
