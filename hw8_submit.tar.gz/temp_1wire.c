#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#include "sensor_name.h"

static double read_temp(char *filename) {

	double result=0.0;
	char yesVal[256], tempVal[256]

	//open file and check for error
	FILE *fff;
	fff = fopen(filename,"r");
	if (fff < 0) printf("error with file open");

	//store top line in yesVal and bottom line in tempVal
	fscanf(fff, "%s %s", yesVal, tempVal);

	//check to see if the top line says "YES"
	int yes = 0;
	for (int i = 0; i < 256; i++){ //loop through //if there is a 'Y' in the string, it must say YES
		if (strcmp(yesVal[i],'Y') == 0){
			yes = 1;
		}
	}

	//if YES on line 1, loop through line 2 to find the beginning and end position of the temp
	if (yes == 1){
		int index = 0;
        	int endIndex = 0;
        	int atTemp = 0;
	        float milli = 0;

		for (int i = 0; i < 256; i++){//loop through entire line
                	if (strcmp(tempVal[i],'t') == 0){//if reached the 't=XXXXX' part
                	        index = i+2; //set begin index to be the first number in XXXX
				atTemp = 1; //we are in the temp area
			}
			if ((atTemp == 1) && (strcmp(tempVal[i],' ') == 0)){
				endIndex = i-1; //save the ending index to be the last number
			}
	        }
		char temps[endIndex-index+1]; //make a new string with the size of the temp reading
		for (int i = index; i < endIndex; i++) {
			temps[i-index] = tempVal[i];//save the temp into the  new variable
		}
		milli = atof(temps); //convert from string to float
		result = milli/1000.0; //convert from milliCelcius to Celcius
	}
	else { //If not YES, wasnt able to establish connection
		printf("Did not establish connection");
		fclose(filename);
		return 0;
	}
	fclose(filename);
	return result;
}

int main(int argc, char **argv) {

	double temp1;

	while(1) {

		temp1=read_temp(SENSOR_NAME);
		printf("%.2lfC\n",temp1);
		sleep(1);
	}

	return 0;
}
