#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <linux/i2c-dev.h>
#include "read_temp.h"

int init_display(void){

	int fd, result;

	unsigned char buffer[17];

        /* Open i2c device */
        fd = open("/dev/i2c-1", O_RDWR);
        if (fd < 0) printf("Could not open file... /n%s",strerror(errno));
        /* Set slave address */
        result=ioctl(fd, I2C_SLAVE, 0x70);
        if (result < 0) printf("Could not set slave address... /n%s",strerror(errno));
        /* Turn on oscillator */
        buffer[0]=(0x2<<4)|(0x1);
        result=write(fd, buffer, 1);
        if (result < 0) printf("Could not start oscillator... /n%s",strerror(errno)); 



	return fd;
}

int write_display(int fd, double value){

	int count, res;
	double  temp;
	if (value >= 0.0 && value <= 99.9){
		//print in 11.1 format, no leading zeros, then degree symbol
		count = 4;
		if (value < 10) count = 3;
		res = write(fd, &value, count);
	}
	else if (value < 0.0 && value >= -99.9){
		//print in -11.1 format, no leading zeros, then degree symbol
		count = 5;
		if (value < 10) count = 4;
                res = write(fd, &value, count);
	}
	else if (value >= 100.0 && value <= 999.0){
                //print in 111 format, no leading zeros, then degree symbol
		count = 5;
		temp = value;
                res = write(fd, &temp, count);
        }
        else if (value < -100.0 && value >= -999.0){
                //print in -111 format, no leading zeros, then degree symbol
		count = 6;
		temp = value;
                res = write(fd, &temp, count);
        }
	else {
		//print "NVAL" for nonvalid
		count = 4;
		unsigned char nval[4] = "NVAL";
                res = write(fd, nval, count);
	}

	if (res != count) {
		printf("Could not write ... /n%s",strerror(errno));
		return 0;
	}
	return 1;

}

int shutdown_display(int fd){

	close(fd);
	return 1;

}

int main(int argc, char **argv) {

	int f = init_display();

	while(1){
		write_display(f, read_temp());
	}
	
	shutdown_display(f);
	return 1;

}
