#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/gpio.h>
#include <sys/time.h>

static void switch_pressed(void) {
	//print out that the switch has been pressed
	struct timeval press_time;

	gettimeofday(&press_time,NULL);
	//print time
	printf("Switch pressed at  %ld.%06ld\n",press_time.tv_sec,press_time.tv_usec);

}

static void switch_released(void) {
	//print out that the switch has been released
	struct timeval release_time;

	gettimeofday(&release_time,NULL);
	//print time
	printf("Switch released at %ld.%06ld\n",release_time.tv_sec,release_time.tv_usec);

}


int main(int argc, char **argv) {
	//set up GPIO
	int fd, rv;
	fd=open("/dev/gpiochip0",O_RDWR);
        if (fd<0) {printf("fd error... %s", strerror(errno)); exit(EXIT_FAILURE);}//check no error
        struct gpiohandle_request req;
        memset(&req,0,sizeof(struct gpiohandle_request));
        req.flags = GPIOHANDLE_REQUEST_INPUT; //set to input
        req.lines = 1;
        req.lineoffsets[0] = 17; //GPIO17
        req.default_values[0] = 0;
        strcpy(req.consumer_label, "ECE471");
        rv = ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL, &req);
	//check error
        if (rv < 0){
                printf("%s... EXITING PROGRAM\n", strerror(errno));
                exit(EXIT_FAILURE);
        }

	//setup struct to request input
	struct gpiohandle_data data;
	int last = 0;
	int pressed = 0;
	int change = 0;

	while(1){//inf loop

		memset(&data, 0, sizeof(data)); //request input
        	rv = ioctl(req.fd, GPIOHANDLE_GET_LINE_VALUES_IOCTL, &data);
		if (rv <0) {printf("rv error...  %s", strerror(errno)); exit(EXIT_FAILURE);}
		last = pressed; //store last reading for later
		pressed = data.values[0]; //store current reading
		
		//debounced check
		if (last != pressed) { // input state changes, wait 50milliseconds and check again to make sure it was a real state change
			change = 1; 
			usleep(50000); 
			if (last == pressed){
				 change = 0;
			} //debounce
		}

		if (change){//if there was a change
			if (pressed) switch_pressed(); //if pressed, notify
			else switch_released();//if not, notify
			change = 0;//set changed back to zero for next time
		}

		usleep(50000); //wait 50 ms to slow down loop
 	}
	
	return 0;
}
