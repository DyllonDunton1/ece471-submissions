#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/gpio.h>
#include <sys/time.h>

static void switch_pressed(void) {
	//tell thta switch was pressed
	struct timeval press_time;

	gettimeofday(&press_time,NULL);

	printf("Switch pressed at  %ld.%06ld\n",press_time.tv_sec,press_time.tv_usec);
	
}

static void switch_released(void) {
	//tell thta switch was released
	struct timeval release_time;

	gettimeofday(&release_time,NULL);

	printf("Switch released at %ld.%06ld\n",release_time.tv_sec,release_time.tv_usec);

	
}


int main(int argc, char **argv) {
	//setup input
	int fd, rv;
	fd=open("/dev/gpiochip0",O_RDWR);
        if (fd<0) {printf("fd error... %s", strerror(errno)); exit(EXIT_FAILURE);}
        
	struct gpiohandle_request req;
        memset(&req,0,sizeof(struct gpiohandle_request));
        req.flags = GPIOHANDLE_REQUEST_INPUT;
        req.lines = 1;
        req.lineoffsets[0] = 17;
        req.default_values[0] = 0;
        strcpy(req.consumer_label, "ECE471_IN");
        rv = ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL, &req);

        if (rv < 0){
                printf("%s... EXITING PROGRAM\n", strerror(errno));
                exit(EXIT_FAILURE);
        }
	
	//setup output
	struct gpiohandle_request ret;
        memset(&ret,0,sizeof(struct gpiohandle_request));
        ret.flags = GPIOHANDLE_REQUEST_OUTPUT;
        ret.lines = 1;
        ret.lineoffsets[0] = 18;
        ret.default_values[0] = 0;
        strcpy(ret.consumer_label, "ECE471_OUT");
        rv = ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL, &ret);


	
	struct gpiohandle_data data; //input data struct
	int last = 0;
	int pressed = 0;
	int change = 0;

	struct gpiohandle_data write; //outpute data struct


	while(1){//inf loop
		//record input
		memset(&data, 0, sizeof(data));
        	rv = ioctl(req.fd, GPIOHANDLE_GET_LINE_VALUES_IOCTL, &data);
		if (rv <0) {printf("rv error...  %s", strerror(errno)); exit(EXIT_FAILURE);}
		last = pressed;
		pressed = data.values[0];
		
		//if change of state
		if (last != pressed) {
			change = 1; 
			usleep(50000); 
			if (last == pressed){
				 change = 0;
			} //debounce
		}

		if (change){
			if (pressed){ //if pressed, notify and turn on led 
				write.values[0]=1;
			        rv = ioctl(ret.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL, &write);
				switch_pressed();
			}
			else{// if not, notify and turn off led
				switch_released();
				write.values[0]=0;
			        rv = ioctl(ret.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL, &write);
			}
			change = 0;
		}

		usleep(50000);
 	}
	
	return 0;
}
