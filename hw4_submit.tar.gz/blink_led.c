#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>
#include <errno.h>

#include "linux/gpio.h"
#include "sys/ioctl.h"

int main(int argc, char **argv) {

	int fd;
	int rv;
	/* open the gpio device */
	fd=open("/dev/gpiochip0",O_RDWR);
	//check to make sure no error
	if (fd<0) {printf("fd error... %s", strerror(errno)); exit(EXIT_FAILURE);}
	struct gpiohandle_request req;
	memset(&req,0,sizeof(struct gpiohandle_request));
	req.flags = GPIOHANDLE_REQUEST_OUTPUT; //set to output
	req.lines = 1;
	req.lineoffsets[0] = 18; //GPIO18
	req.default_values[0] = 0; //default value
	strcpy(req.consumer_label, "ECE471");
	rv = ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL, &req);
	//make sure no error
	if (rv < 0){
                printf("%s... EXITING PROGRAM\n", strerror(errno));
                exit(EXIT_FAILURE);
        }

	//set value to 0
	struct gpiohandle_data data;
	data.values[0]=0; // value to output (0 or 1)
	rv=ioctl(req.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data);
	//check no error
	if (rv < 0){
		printf("GPIO ERROR... EXITING PROGRAM\n");
		exit(EXIT_FAILURE);
	}	


	while(1){ //inf loop
		//set high
		data.values[0] = 1;
		rv = ioctl(req.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data);
		if (rv<0) {printf("rv error... %s", strerror(errno)); exit(EXIT_FAILURE);}
		usleep(500000);//wait 0.5 sec
		//set low
		data.values[0] = 0;
                rv = ioctl(req.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data);
		if (rv<0) {printf("rv error... %s", strerror(errno)); exit(EXIT_FAILURE);}
                usleep(500000); //wait 0.5sec

	}
	

	return 0;
}
