#include <stdio.h>

int main(int argc, char **argv) {

	for (int i =1; i <=10; i++){ //loop that runs from i=1 to i=10 inclusive
		printf("%d: ECE471 Ham sandwich\n", i); //prints the id for the message (i:), then prints "ECE471 Ham Sandwich" and drops down a line
 	}

	return 0;
}
