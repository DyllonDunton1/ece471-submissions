#include <stdio.h>

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/spi/spidev.h>


int main(int argc, char **argv) {

        int spi_fd;
	int result;
	# define LENGTH 3

	/* Open SPI device */
	spi_fd=open("/dev/spidev0.0",O_RDWR);
	if (spi_fd < 0) printf("Wrong file descriptor");
	/* Set SPI Mode_0 */
	int mode = SPI_MODE_0;
	char channel = 0x80 | ((0x002)<<4);
	result = ioctl(spi_fd, SPI_IOC_WR_MODE, &mode);
	struct spi_ioc_transfer spi ;
	unsigned char data_out [ LENGTH ]={0x01 ,channel ,0x00 };
	unsigned char data_in [ LENGTH ];
	/* kernel doesn ’t like it if stray values , even in padding */
	memset (&spi , 0, sizeof(struct spi_ioc_transfer));
	/* Setup full - duplex transfer of 3 bytes */
	spi.tx_buf = (unsigned long)& data_out ;
	spi.rx_buf = (unsigned long)& data_in ;
	spi.len = LENGTH ;
	spi.delay_usecs = 0 ;
	spi.speed_hz = 100000 ; // required
	spi.bits_per_word = 8 ;
	spi.cs_change = 0 ;

	/* Run full - duplex transaction every second*/
	while(1){
		channel = 0x80 | ((0x0)<<4); //set channel 0
		data_out[1] = channel;
		result = ioctl(spi_fd, SPI_IOC_MESSAGE(1), &spi) ; //grab new spi reading
		result = result + result - result;//get rid of warning

		int recieved_low = ((data_in[1] & 0x7)<<8) | data_in[2]; //put into integer 
		float vin_low = (3.3)*(float)recieved_low/1024;//put into voltage low

		channel = 0x80 | ((0x1)<<4);//set channel 1
                data_out[1] = channel;
                result = ioctl(spi_fd, SPI_IOC_MESSAGE(1), &spi) ; //grab new spi reading
                result = result + result - result;//get rid of warning

                int recieved_high = ((data_in[1] & 0x7)<<8) | data_in[2];//put into integer
                float vin_high = (3.3)*(float)recieved_high/1024;//put into voltage high


        	printf("vin_low: %f | vin_high: %f\n", vin_low, vin_high);//concatenate all into one string to print

		sleep(1);//wait 1 second for polling frequency of 1 Hz

	}

	return 0;
}
