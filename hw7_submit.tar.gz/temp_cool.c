#include <stdio.h>

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/spi/spidev.h>


int main(int argc, char **argv) {

        int spi_fd;
	int result;
	# define LENGTH 3

	/* Open SPI device */
	spi_fd=open("/dev/spidev0.0",O_RDWR);
	if (spi_fd < 0) printf("Wrong file descriptor");
	/* Set SPI Mode_0 */
	int mode = SPI_MODE_0;
	char channel = 0x80 | ((0x002)<<4);
	result = ioctl(spi_fd, SPI_IOC_WR_MODE, &mode);
	struct spi_ioc_transfer spi ;
	unsigned char data_out [ LENGTH ]={0x01 ,channel ,0x00 };
	unsigned char data_in [ LENGTH ];
	/* kernel doesn ’t like it if stray values , even in padding */
	memset (&spi , 0, sizeof(struct spi_ioc_transfer));
	/* Setup full - duplex transfer of 3 bytes */
	spi.tx_buf = (unsigned long)& data_out ;
	spi.rx_buf = (unsigned long)& data_in ;
	spi.len = LENGTH ;
	spi.delay_usecs = 0 ;
	spi.speed_hz = 100000 ; // required
	spi.bits_per_word = 8 ;
	spi.cs_change = 0 ;

	//store max temp
	float max_c = 0;
	float max_f = 0;
	//store min temp
	float min_c = 1000000;//set really high so first temp will be lower
	float min_f = 1000000;

	/* Run full - duplex transaction every second*/
	while(1){
		result = ioctl(spi_fd, SPI_IOC_MESSAGE(1), &spi) ;//grab new spi reading
		result = result + result - result;//get rid of warning
		int recieved = ((data_in[1] & 0x7)<<8) | data_in[2]; //mix all the 3 reieved bytes into an integer
		float vin = (3.3)*(float)recieved/1024; //convert to voltage
		float deg_C = (100.0*vin) - 50.0; //convert voltage to celcius
		float deg_F = (deg_C * 1.8) + 32.0; //convert celcius into farenheit

		if (deg_C < min_c) { //if current temp is lower than min, set to new min
			min_c = deg_C;
			min_f = deg_F;
		}
		if (deg_C > max_c) {//if current temp is higher than max, set to new max
                        max_c = deg_C;
                        max_f = deg_F;
                }

        	printf("Current_C: %f | Current_F: %f| max_C: %f | max_F: %f | min_C: %f | min_F: %f\n", deg_C, deg_F, max_c, max_f, min_c, min_f);//print it out

		sleep(1);

	}

	return 0;
}
